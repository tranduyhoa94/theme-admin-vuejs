(function ($) {
    "use strict";
	
	var $window = $(window); 
	var $body = $('body'); 
	
	/* Preloader Effect */
	$window.on( "load", function() {
	   $(".preloader").fadeOut(600);
    });
	
	/* Sticky header */
	$window.scroll(function(){
    	if ($window.scrollTop() > 100) {
			$('.navbar').addClass('sticky-header');
		} else {
			$('.navbar').removeClass('sticky-header');
		}
	});
		
	/* slick nav */
	$('#main-menu').slicknav({prependTo:'#responsive-menu',label:'', closeOnClick:true});
	
	/* Screenshot slider */
	var swiper = new Swiper('.screenshot-slider',{
		slidesPerView: 3,
		spaceBetween: 20,
		navigation: {
			nextEl: '.screenshot-next',
			prevEl: '.screenshot-prev',
		},
		breakpoints: {
			567: {
				slidesPerView: 1,
				spaceBetween: 0
			}
		}
    });

	var $clock = $("#clock"); 
	if($clock.length){
		var $date	=	$clock.attr('data-date');
		if($date!=''){
			$clock.countdown($date, function(event) {
			  var $this = $(this).html(event.strftime(''
				+ '<div class="countdown">%D <span>Days</span></div>'
				+ '<div class="countdown">%H <span>Hours</span></div>'
				+ '<div class="countdown">%M <span>Minutes</span></div>'
				+ '<div class="countdown">%S <span>Seconds</span></div>'));
			});
		}
	}
})(jQuery);