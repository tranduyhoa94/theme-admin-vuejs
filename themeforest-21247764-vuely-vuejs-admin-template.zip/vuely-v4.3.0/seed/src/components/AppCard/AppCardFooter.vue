<template>
  <div class="app-footer">
      <slot></slot>
  </div>
</template>
