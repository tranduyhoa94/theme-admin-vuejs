<template>
   <div>
      <ais-search-box>
         <ais-input
            class="border input-group pa-2 fs-14"
            placeholder="Search product"
         ></ais-input>
      </ais-search-box>
   </div>
</template>   