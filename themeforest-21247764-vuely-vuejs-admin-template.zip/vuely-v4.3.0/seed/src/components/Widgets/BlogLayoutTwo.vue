<!-- BlogLayoutTwo Widget -->
<template>
   <!-- Blog Card -->
	<div>
		<v-card-title class="pa-4">
			<div>
				<h4 class="mb-0">Where Can You Find Unique Myspace Layouts Nowadays</h4>
				<span class="grey--text fs-12" >11 Nov 2017 , By: Admin , 5 Comments </span>
			</div>
		</v-card-title>                
		<v-img src="/static/img/blog-6.jpg" height="240px"> </v-img>
		<v-card-text class="px-4 py-3">
			Consectetur adipisicing elit. Ullam expedita, necessitatibus sit exercitationem aut quo quos inventore, similique nulla minima distinctio illo iste dignissimos vero nostrum, magni pariatur delectus natus.      
		</v-card-text>
		<v-card-actions class="px-4 py-2">
			<v-btn icon>
			<v-icon color="success">share</v-icon>
			</v-btn>
			<v-btn icon>
			<v-icon color="error">favorite</v-icon>
			</v-btn>
			<v-spacer></v-spacer>
			<v-btn icon>
				<v-icon class="grey--text">more_horiz</v-icon>
			</v-btn>
		</v-card-actions>   
	</div>
</template>