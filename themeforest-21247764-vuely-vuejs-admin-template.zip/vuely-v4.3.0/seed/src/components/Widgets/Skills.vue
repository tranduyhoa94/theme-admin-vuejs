<template>
   <v-card-text>
		<ul class="list-unstyled card-list">
			<li>
				<p class="fw-bold">HTML</p>
				<v-progress-linear value="20" height="5" color="white"></v-progress-linear>
			</li>
			<li>
				<p class="fw-bold">Css3</p>
				<v-progress-linear value="90" height="5" color="white"></v-progress-linear>
			</li>
			<li>
				<p class="fw-bold">Photoshop</p>
				<v-progress-linear value="30" height="5" color="white"></v-progress-linear>
			</li>
			<li>
				<p class="fw-bold">Javascript</p>
				<v-progress-linear value="75" height="5" color="white"></v-progress-linear>
			</li>
		</ul>
	</v-card-text>
</template>
