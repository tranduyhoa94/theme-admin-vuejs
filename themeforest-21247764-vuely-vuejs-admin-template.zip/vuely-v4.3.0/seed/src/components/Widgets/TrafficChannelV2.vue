<template>
   <v-list class="traffic-channel-widget">
      <v-list-tile>
         <p>Direct</p>
         <div>
            <span>55%</span>
            <v-progress-linear value="55" height="7" color="primary"></v-progress-linear>
         </div>
      </v-list-tile>
      <v-list-tile>
         <p>Referral</p>
         <div>
            <span>78%</span>
            <v-progress-linear value="78" height="7" color="primary"></v-progress-linear>
         </div>
      </v-list-tile>
      <v-list-tile>
         <p>Facebook</p>
         <div>
            <span>68%</span>
            <v-progress-linear value="68" height="7" color="primary"></v-progress-linear>
         </div>
      </v-list-tile>
      <v-list-tile>
         <p>Google</p>
         <div>
            <span>23%</span>
            <v-progress-linear value="23" height="7" color="primary"></v-progress-linear>
         </div>
      </v-list-tile>
      <v-list-tile>
         <p>Instagram</p>
         <div>
            <span>57%</span>
            <v-progress-linear value="57" height="7" color="primary"></v-progress-linear>
         </div>
      </v-list-tile>
   </v-list>
</template>
