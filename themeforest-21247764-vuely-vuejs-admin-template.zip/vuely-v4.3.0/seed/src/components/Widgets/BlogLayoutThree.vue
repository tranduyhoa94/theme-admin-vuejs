<!-- BlogLayoutThree Widget -->
<template>
   <div>
      <v-img
         class="white--text"
         src="/static/img/carousel-slider-2.jpg" height="330px"
      >
      <v-container fill-height fluid>
         <v-layout fill-height>
            <v-flex xs12 align-end flexbox>
               <span class="headline">Top 10 Australian beaches</span>
            </v-flex>
         </v-layout>
         </v-container>
      </v-img>
      <v-card-title class="px-4 py-3">
         <div>
				<span class="grey--text fs-12">Number 10</span><br>
				<p class="mb-0">Whitehaven Beach Whitsunday Island, Whitsunday Islands, 
               Ullam expedita, necessitatibus sit exercitationem aut quo quos inventore,
            </p>
         </div>
      </v-card-title>
      <v-card-actions>
         <v-btn icon>
            <v-icon color="success">share</v-icon>
         </v-btn>
         <v-btn icon>
            <v-icon color="error">favorite</v-icon>
         </v-btn>
         <v-spacer></v-spacer>
         <v-btn icon>
            <v-icon class="grey--text">more_horiz</v-icon>
         </v-btn>
      </v-card-actions>
   </div>
</template>