export default {
   primary: '#FF3739',
   secondary: '#424242',
   accent: '#82B1FF',
   error: '#5D92F4',
   info: '#00D0BD',
   success: '#00D014',
   warning: '#FFB70F'
}